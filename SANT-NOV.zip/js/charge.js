$(document).ready(function () {
    /*General*/
    $('.footer').load('footer.html');
});